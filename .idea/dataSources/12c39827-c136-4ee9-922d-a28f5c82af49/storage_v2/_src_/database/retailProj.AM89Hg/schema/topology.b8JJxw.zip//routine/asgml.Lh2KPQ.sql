create function asgml(tg topology.topogeometry)
  returns text
stable
language sql
as $$
SELECT topology.AsGML($1, 'gml');
$$;

comment on function asgml(topology.topogeometry)
is 'args: tg - Returns the GML representation of a topogeometry.';

alter function asgml(topology .topogeometry)
  owner to postgres;

