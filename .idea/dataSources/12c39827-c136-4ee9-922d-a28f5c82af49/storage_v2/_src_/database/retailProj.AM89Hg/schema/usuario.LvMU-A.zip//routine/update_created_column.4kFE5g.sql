create function update_created_column()
  returns trigger
language plpgsql
as $$
BEGIN NEW.creado = now(); RETURN NEW;END;
$$;

alter function update_created_column()
  owner to danielmc86;

