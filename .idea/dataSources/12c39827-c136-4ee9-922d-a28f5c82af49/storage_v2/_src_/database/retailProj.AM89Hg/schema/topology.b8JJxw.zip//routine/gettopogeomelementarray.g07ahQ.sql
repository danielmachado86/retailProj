create function gettopogeomelementarray(tg topology.topogeometry)
  returns topology.topoelementarray
stable
strict
language plpgsql
as $$
DECLARE
  toponame varchar;
BEGIN
  toponame = topology.GetTopologyName(tg.topology_id);
  RETURN topology.GetTopoGeomElementArray(toponame, tg.layer_id, tg.id);
END;
$$;

comment on function gettopogeomelementarray(topology.topogeometry)
is 'args: tg - Returns a topoelementarray (an array of topoelements) containing the topological elements and type of the given TopoGeometry (primitive elements)';

alter function gettopogeomelementarray(topology .topogeometry)
  owner to postgres;

