create function createtopogeom(toponame character varying, tg_type integer, layer_id integer)
  returns topology.topogeometry
strict
language sql
as $$
SELECT topology.CreateTopoGeom($1,$2,$3,'{{0,0}}');
$$;

comment on function createtopogeom(varchar, integer, integer)
is 'args: toponame, tg_type, layer_id - Creates a new topo geometry object from topo element array - tg_type: 1:[multi]point, 2:[multi]line, 3:[multi]poly, 4:collection';

alter function createtopogeom(varchar, integer, integer)
  owner to postgres;

