create function update_modified_column()
  returns trigger
language plpgsql
as $$
BEGIN NEW.modificado = now(); RETURN NEW;END;
$$;

alter function update_modified_column()
  owner to danielmc86;

