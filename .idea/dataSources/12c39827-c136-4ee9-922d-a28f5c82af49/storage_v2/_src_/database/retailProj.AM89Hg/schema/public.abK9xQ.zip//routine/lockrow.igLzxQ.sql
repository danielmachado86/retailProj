create function lockrow(text, text, text, text)
  returns integer
strict
language sql
as $$
SELECT LockRow($1, $2, $3, $4, now()::timestamp+'1:00');
$$;

alter function lockrow(text, text, text, text)
  owner to postgres;

