create function geometrytype(tg topology.topogeometry)
  returns text
stable
strict
language sql
as $$
SELECT CASE
		WHEN type($1) = 1 THEN 'MULTIPOINT'
		WHEN type($1) = 2 THEN 'MULTILINESTRING'
		WHEN type($1) = 3 THEN 'MULTIPOLYGON'
		WHEN type($1) = 4 THEN 'GEOMETRYCOLLECTION'
		ELSE 'UNEXPECTED'
		END;
$$;

alter function geometrytype(topology .topogeometry)
  owner to postgres;

