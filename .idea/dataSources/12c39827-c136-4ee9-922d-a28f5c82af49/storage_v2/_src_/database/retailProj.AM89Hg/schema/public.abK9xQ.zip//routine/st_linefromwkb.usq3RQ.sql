create function st_linefromwkb(bytea)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

comment on function st_linefromwkb(bytea)
is 'args: WKB - Makes a LINESTRING from WKB with the given SRID';

alter function st_linefromwkb(bytea)
  owner to postgres;

