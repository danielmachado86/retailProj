create function addtopogeometrycolumn(character varying, character varying, character varying, character varying, character varying)
  returns integer
language sql
as $$
SELECT topology.AddTopoGeometryColumn($1, $2, $3, $4, $5, NULL);
$$;

comment on function addtopogeometrycolumn(varchar, varchar, varchar, varchar, varchar)
is 'args: topology_name, schema_name, table_name, column_name, feature_type - Adds a topogeometry column to an existing table, registers this new column as a layer in topology.layer and returns the new layer_id.';

alter function addtopogeometrycolumn(varchar, varchar, varchar, varchar, varchar)
  owner to postgres;

