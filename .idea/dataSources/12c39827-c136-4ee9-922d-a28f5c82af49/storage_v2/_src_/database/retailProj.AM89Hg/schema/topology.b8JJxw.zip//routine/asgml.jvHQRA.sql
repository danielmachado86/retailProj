create function asgml(tg topology.topogeometry, nsprefix text, prec integer, options integer, visitedtable regclass, idprefix text)
  returns text
language sql
as $$
SELECT topology.AsGML($1, $2, $3, $4, $5, $6, 3);
$$;

comment on function asgml(topology.topogeometry, text, integer, integer, regclass, text)
is 'args: tg, nsprefix_in, precision, options, visitedTable, idprefix - Returns the GML representation of a topogeometry.';

alter function asgml(topology .topogeometry, text, integer, integer, regclass, text)
  owner to postgres;

