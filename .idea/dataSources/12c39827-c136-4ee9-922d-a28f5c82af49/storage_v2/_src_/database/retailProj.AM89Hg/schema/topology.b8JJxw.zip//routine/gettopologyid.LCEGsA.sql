create function gettopologyid(toponame character varying)
  returns integer
stable
strict
language plpgsql
as $$
DECLARE
  ret integer;
BEGIN
  SELECT id INTO ret
    FROM topology.topology WHERE name = toponame;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Topology % does not exist', quote_literal(toponame);
  END IF;

  RETURN ret;
END
$$;

comment on function gettopologyid(varchar)
is 'args: toponame - Returns the SRID of a topology in the topology.topology table given the name of the topology.';

alter function gettopologyid(varchar)
  owner to postgres;

