create function cleartopogeom(tg topology.topogeometry)
  returns topology.topogeometry
strict
language plpgsql
as $$
DECLARE
  topology_info RECORD;
  sql TEXT;
BEGIN

  -- Get topology information
  SELECT id, name FROM topology.topology
    INTO topology_info
    WHERE id = topology_id(tg);
  IF NOT FOUND THEN
      RAISE EXCEPTION 'No topology with id "%" in topology.topology', topology_id(tg);
  END IF;

  -- Clear the TopoGeometry contents
  sql := 'DELETE FROM ' || quote_ident(topology_info.name)
        || '.relation WHERE layer_id = '
        || layer_id(tg)
        || ' AND topogeo_id = '
        || id(tg);
  EXECUTE sql;


  RETURN tg;

END
$$;

comment on function cleartopogeom(topology.topogeometry)
is 'args: topogeom - Clears the content of a topo geometry';

alter function cleartopogeom(topology .topogeometry)
  owner to postgres;

